# oncotarget-lite

![PyPI](https://img.shields.io/badge/PyPI-coming%20soon-lightgrey)
[![CI](https://github.com/altalanta/oncotarget-lite/actions/workflows/ci.yml/badge.svg)](https://github.com/altalanta/oncotarget-lite/actions/workflows/ci.yml)
![Coverage](https://img.shields.io/badge/coverage-%E2%89%A590%25-brightgreen)
[![Docs](https://img.shields.io/badge/docs-mkdocs%20material-2e7dd7)](https://altalanta.github.io/oncotarget-lite)

Lean, laptop-first pipeline for immunotherapy target triage. The project hardens packaging, observability, and reproducibility without changing the original scientific intent.

- ✅ **Installable package** (`pip install oncotarget-lite`) with extras for docs/tests (`[dev]`) and the Streamlit app (`[viz]`).
- ✅ **Deterministic ML stack**: schema checks → feature engineering → interpretable scorecard → PyTorch MLP → AUROC/AUPRC/Brier/ECE with bootstrap CIs.
- ✅ **Governed artifacts**: JSON metrics, Parquet predictions & feature importances, lineage metadata (inputs, git SHA, params, environment).
- ✅ **Structured logging** with run + lineage identifiers and optional MLflow toggle via `ONCOTARGET_LITE_MLFLOW=1`.
- ✅ **Docs & CI**: MkDocs Material site, Ruff → Mypy → Pytest (Py3.10–3.12) → wheel build, ≥90% coverage gate.

The synthetic CSV caches ship with the repo so every workflow runs fully offline in under two minutes on a CPU laptop.

## Quickstart

```bash
python -m pip install --upgrade pip
pip install oncotarget-lite[viz]

oncotarget-lite system-info
oncotarget-lite validate-data
oncotarget-lite train --device cpu --out artifacts/
# copy the "artifacts" path from the JSON output
oncotarget-lite evaluate --run-dir artifacts/<run_id>
oncotarget-lite report --run-dir artifacts/<run_id>
```

Streamlit explorer:

```bash
oncotarget-lite app run --port 8501
```

For development checkout:

```bash
git clone https://github.com/altalanta/oncotarget-lite.git
cd oncotarget-lite
pip install -e .[dev,viz]
```

## CLI at a glance

| Command | Purpose |
| --- | --- |
| `system-info` | Python + library versions, CUDA availability |
| `config --show/--validate` | Inspect or validate YAML config |
| `validate-data` | Enforce Pydantic/polars data contracts |
| `train` | Run end-to-end pipeline, write artifacts + lineage |
| `evaluate` | Recompute metrics from `predictions.parquet` |
| `report` | Summarise metrics + top-ranked targets |
| `app run` | Launch Streamlit explorer (requires `[viz]`) |

All commands accept `--config-file` overrides and emit JSON by default (TTY modes include compact tables for readability).

## Pipeline Outputs

Running `oncotarget-lite train` produces:

- `metrics.json` – AUROC/AUPRC/Brier/ECE with 95% bootstrap CIs and calibration bins.
- `predictions.parquet` – train/test probabilities and labels.
- `feature_importances.parquet` – first-layer weight attribution.
- `scores.parquet` – interpretable scorecard contributions + rank.
- `lineage.json` – input SHA256 hashes, git SHA, params, environment.
- `model.pt` – MLP state dict aligned with saved feature order.

Each run is deterministic when seeds are fixed (data splits, model init, bootstrap resampling).

## Data & Features

Synthetic caches emulate GTEx, TCGA, DepMap, UniProt, and STRING summary statistics for ~50 genes. Schema validation blocks missing columns, negative expression values, empty dependency dictionaries, or inconsistent annotations before training executes.

Feature engineering derives:

- Log2 fold-change per tumour vs. mean normal expression (`log2fc_*`).
- Minimum normal TPM, mean tumour TPM, and mean dependency scores.
- Protein annotations (signal peptide, Ig-like domain, protein length) plus PPI degree.
- Binary labels describing cell-surface localisation.

## Tests & Quality Gates

```bash
make lint    # ruff + mypy
make test    # pytest --cov ≥90%
```

CI (`.github/workflows/ci.yml`) runs lint → mypy → tests (Py3.10, 3.11, 3.12) → wheel build. Coverage thresholds are enforced via pytest-cov and the workflow uploads coverage XML for badge generation.

## Documentation

MkDocs Material site: <https://altalanta.github.io/oncotarget-lite>

- Overview & architecture diagram
- Quickstart (exact CLI commands)
- Data schema reference
- CLI reference & limits
- Reproduce-the-figures notebook snippets
- Tiny model card summarising the MLP

Run locally with `make docs-serve` (requires `[dev]`).

## Docker

Multi-stage image builds a wheel in an isolated layer and ships a slim runtime with a non-root user, healthcheck, and Streamlit entrypoint:

```bash
make docker-build
docker run -p 8501:8501 oncotarget-lite:latest
```

## Release plan (v0.3.0)

1. Ensure CI is green and coverage ≥90%.
2. Build artifacts: `python -m build` (wheel + sdist).
3. Tag `v0.3.0` and push the tag.
4. Create a GitHub Release attaching the wheel/sdist.
5. Optional PyPI publish: `python -m twine upload dist/*` (replace the PyPI badge once live).

## Limits

- Synthetic data only – not suitable for biological decisions.
- Toy MLP sized for CPU laptops; no GPU-specific optimisations.
- Scorecard weights are pedagogical heuristics, not safety guarantees.
- Confidence intervals use simple bootstrap resampling of a small dataset.
- Optional MLflow logging is disabled by default to keep everything offline.

